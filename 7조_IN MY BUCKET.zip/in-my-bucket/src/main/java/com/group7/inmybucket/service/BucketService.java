package com.group7.inmybucket.service;

import java.util.List;

import com.group7.inmybucket.dto.BucketDTO;
import com.group7.inmybucket.dto.ImageFileDTO;
import com.group7.inmybucket.vo.LikeVO;

public interface BucketService {
	public int bucketInsert(BucketDTO dto);
	public int bucketDelete(int bucket_no);
	public int imageFileInsert(List<ImageFileDTO> filelist);
	public List<BucketDTO> bucketAllSelect();
	public BucketDTO bucketSelect(int bucket_no);
	public List<ImageFileDTO> imageFileSelect(int bucket_no);
	public BucketDTO bucketEditSelect(int bucket_no, String userid);
	public List<String> imageFilenameList(int bucket_no);
	public int bucketEditUpdate(BucketDTO dto);
	public int bucketEditDelete(int bucket_no, String userid);
	public int imageFileDelete(int bucket_no);
	public int imageFileEditInsert(List<ImageFileDTO> imageDTOList);
	public BucketDTO bucketReportSelect(int bucket_no, String userid);
	public int bucketSaveLike(LikeVO vo); 
	public int bucketLikeUp(LikeVO vo); 
	public int bucketRemoveLike(LikeVO vo);
	public int bucketLikeDown(LikeVO vo);
	public int bucketLikeCount(LikeVO vo);
	public Integer isLike(LikeVO vo);
	public int commentCount(int bucket_no);
	public List<String> groupMemberNick(int bucket_no);
	public int isGroupRequest(int bucket_no, String userid);
	public int groupQueueInsert(int bucket_no, String userid);
	public int groupMemberInsert(BucketDTO dto);
}
