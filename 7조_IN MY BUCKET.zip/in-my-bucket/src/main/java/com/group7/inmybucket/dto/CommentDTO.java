package com.group7.inmybucket.dto;

import java.util.List;

public class CommentDTO {
	private int c_no; // 일련번호
	private int no; // 원글번호
	private String coment;
	private String userid;
	private String writedate;
	private String ip;
	private String usernick;

	// 여러개의 레코드 한번에 삭제할 때 필요한 레코드 번호
	private List<Integer> noList;
	

	@Override
	public String toString() {
		return "CommentDTO [c_no=" + c_no + ", no=" + no + ", coment=" + coment + ", userid=" + userid + ", writedate="
				+ writedate + ", ip=" + ip + ", usernick=" + usernick + "]";
	}
	public int getC_no() {
		return c_no;
	}
	public void setC_no(int c_no) {
		this.c_no = c_no;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getComent() {
		return coment;
	}
	public void setComent(String coment) {
		this.coment = coment;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getWritedate() {
		return writedate;
	}
	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getUsernick() {
		return usernick;
	}
	public void setUsernick(String usernick) {
		this.usernick = usernick;
	}

	// ---------------------------------------
	public List<Integer> getNoList() {
		return noList;
	}

	public void setNoList(List<Integer> noList) {
		this.noList = noList;
	}
	
	
	
}
