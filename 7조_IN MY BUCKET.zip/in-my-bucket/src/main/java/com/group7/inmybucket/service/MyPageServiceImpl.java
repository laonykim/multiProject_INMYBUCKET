package com.group7.inmybucket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.MyPageDAO;
import com.group7.inmybucket.dto.FeedDTO;
import com.group7.inmybucket.dto.ImageFileDTO;
import com.group7.inmybucket.dto.ProfileDTO;
import com.group7.inmybucket.vo.FilteringVO;
import com.group7.inmybucket.vo.UserDataVO;
import com.group7.inmybucket.vo.UserFeedVO;

@Service
public class MyPageServiceImpl implements MyPageService {
	@Autowired
	MyPageDAO dao;
	
	public ProfileDTO getProfile(String userid) {
		return dao.getProfile(userid);
	}

	@Override
	public String getUsernick(String userid) {
		return dao.getUsernick(userid);
	}

	@Override
	public int updateMypageUser(ProfileDTO dto) {
		return dao.updateMypageUser(dto);
	}

	@Override
	public int updateMypageNickname(String userid, String nickname) {
		return dao.updateMypageNickname(userid, nickname);
	}

	@Override
	public List<FeedDTO> listMine(UserFeedVO vo) {
		return dao.listMine(vo);
	}

	@Override
	public int feedCount(UserFeedVO vo) {
		return dao.feedCount(vo);
	}

	@Override
	public List<FeedDTO> listLike(UserFeedVO vo) {
		return dao.listLike(vo);
	}

	@Override
	public UserDataVO getUserData(String userid) {
		return dao.getUserData(userid);
	}

	@Override
	public int profileImageUpdate(List<ProfileDTO> filelist) {
		return dao.profileImageUpdate(filelist);
	}
}
