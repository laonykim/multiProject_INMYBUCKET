package com.group7.inmybucket.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.group7.inmybucket.vo.PagingVO;
import com.group7.inmybucket.vo.RegisterVO;



public interface RegisterServiece {
	//아이디 중복검사
	public int idCheckCount(String userid);
	//회원가입
	public int registerInsert(RegisterVO vo);
	//로그인
	public RegisterVO loginOk(String userid, String userpwd, String username, String usernick, String permission, String email);
	//회원가입
	public RegisterVO registerEdit(String userid);
	//회원가입 수정 
	public int registerEditOk(RegisterVO vo);
	//아이디찾기
	RegisterVO memberIdSearch(RegisterVO searchVO);
	
	//비번 변경
	int passwordUpdate(RegisterVO searchVO);
	//비번 메일
	public String psSearch(String username, String email);
	//회원탈퇴
	public int remove(RegisterVO vo);
	public RegisterVO removeForm(String userid, String userpwd);
	public int registerprofile(RegisterVO vo);
	public int kakaoOk(RegisterVO userTO);
	public RegisterVO kaka(RegisterVO userTo);
	
	//관리자
	//회원 목록
	public List<RegisterVO> userlist(PagingVO vo);
	public int totalRecord(PagingVO vo);
	public List<RegisterVO> pageSelect(PagingVO vo);
	public RegisterVO userSelect(int no);
	// 삭제
	public int userDelete(RegisterVO vo);
	public int userMultiLineDelete(List<String> noList);
}
