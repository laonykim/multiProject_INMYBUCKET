package com.group7.inmybucket.dto;

import org.springframework.web.multipart.MultipartFile;

public class ImageFileDTO {
	private int bucket_no;
	private String filename;
	private MultipartFile image;
	

	

	@Override
	public String toString() {
		return "ImageFileDTO [bucket_no=" + bucket_no + ", filename=" + filename + ", image=" + image + "]";
	}

	public MultipartFile getImage() {
		return image;
	}

	public void setImage(MultipartFile image) {
		this.image = image;
	}

	public int getBucket_no() {
		return bucket_no;
	}

	public void setBucket_no(int bucket_no) {
		this.bucket_no = bucket_no;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	
	
	
	
}
