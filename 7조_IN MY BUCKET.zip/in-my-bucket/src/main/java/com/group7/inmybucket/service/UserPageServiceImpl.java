package com.group7.inmybucket.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.UserPageDAO;
import com.group7.inmybucket.dto.FeedDTO;
import com.group7.inmybucket.dto.ProfileDTO;
import com.group7.inmybucket.vo.UserDataVO;
import com.group7.inmybucket.vo.UserFeedVO;

@Service
public class UserPageServiceImpl implements UserPageService {
	@Inject
	UserPageDAO dao;

	@Override
	public int feedCount(UserFeedVO vo) {
		return dao.feedCount(vo);
	}

	@Override
	public List<FeedDTO> listUser(UserFeedVO vo) {
		return dao.listUser(vo);
	}

	@Override
	public ProfileDTO getProfile(String userid) {
		return dao.getProfile(userid);
	}

	@Override
	public String getUsernick(String userid) {
		return dao.getUsernick(userid);
	}

	@Override
	public UserDataVO getUserData(String userid) {
		return dao.getUserData(userid);
	}

	@Override
	public int getProfileVisible(String userid) {
		return dao.getProfileVisible(userid);
	}
}
