package com.group7.inmybucket.vo;

public class UserFeedVO {
	private FilteringVO vo;
	private String userid;
	
	
	@Override
	public String toString() {
		return "UserFeedVO [vo=" + vo + ", userid=" + userid + "]";
	}
	public FilteringVO getVo() {
		return vo;
	}
	public void setVo(FilteringVO vo) {
		this.vo = vo;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	
}
