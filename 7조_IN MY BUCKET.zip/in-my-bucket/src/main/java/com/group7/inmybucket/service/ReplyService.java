package com.group7.inmybucket.service;

import java.util.List;

import com.group7.inmybucket.dto.ReplyDTO;

public interface ReplyService {
	public int replyInsert(ReplyDTO dto);
	public List<ReplyDTO> replyListSelect(int bucket_no);
	public int replyUpdate(ReplyDTO dto);
	public int replyDelete(int comment_no, String userid);
}
