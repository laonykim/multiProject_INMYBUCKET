package com.group7.inmybucket.service;

import java.util.List;



import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.BoardDAO;
import com.group7.inmybucket.dto.BoardDTO;
import com.group7.inmybucket.vo.PagingVO;



@Service
public class BoardServiceImpl implements BoardService {
	@Inject
	BoardDAO dao;

	@Override
	public int boardInsert(BoardDTO dto) {
		return dao.boardInsert(dto);
	}

	@Override
	public int totalRecord(PagingVO vo) {
		return dao.totalRecord(vo);
	}

	@Override
	public List<BoardDTO> pageSelect(PagingVO vo) {
		return dao.pageSelect(vo);
	}

	@Override
	public BoardDTO boardSelect(int no) {
		return dao.boardSelect(no);
	}

	@Override
	public BoardDTO boardEditSelect(int no) {
		return dao.boardEditSelect(no);
	}

	@Override
	public int boardUpdate(BoardDTO dto) {
		return dao.boardUpdate(dto);
	}

	@Override
	public void boardHitCount(int no) {
		dao.boardHitCount(no);
	}

	@Override
	public int boardDelete(BoardDTO dto) {
		return dao.boardDelete(dto);
	}

	@Override
	public int boardMultiLineDelete(List<Integer> noList) {
		return dao.boardMultiLineDelete(noList);
	}
	@Override
	public int adboardDelete(BoardDTO dto) {
		return dao.boardDelete(dto);
	}

	@Override
	public int adboardMultiLineDelete(List<Integer> noList) {
		return dao.boardMultiLineDelete(noList);
	}
}
