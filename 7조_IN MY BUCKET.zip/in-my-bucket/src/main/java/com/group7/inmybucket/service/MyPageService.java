package com.group7.inmybucket.service;

import java.util.List;

import com.group7.inmybucket.dto.FeedDTO;
import com.group7.inmybucket.dto.ImageFileDTO;
import com.group7.inmybucket.dto.ProfileDTO;
import com.group7.inmybucket.vo.UserDataVO;
import com.group7.inmybucket.vo.UserFeedVO;

public interface MyPageService {
	public ProfileDTO getProfile(String userid);
	public String getUsernick(String userid);
	public int updateMypageUser(ProfileDTO dto);
	public int updateMypageNickname(String userid, String nickname);
	public UserDataVO getUserData(String userid);
	public int feedCount(UserFeedVO vo);
	public List<FeedDTO> listMine(UserFeedVO vo);
	public List<FeedDTO> listLike(UserFeedVO vo);
	public int profileImageUpdate(List<ProfileDTO> filelist);
}
