package com.group7.inmybucket.service;

import java.util.List;


import com.group7.inmybucket.dto.BoardDTO;
import com.group7.inmybucket.vo.PagingVO;




public interface BoardService {
	public int boardInsert(BoardDTO dto);
	public int totalRecord(PagingVO vo);
	public List<BoardDTO> pageSelect(PagingVO vo);
	public BoardDTO boardSelect(int no);
	public BoardDTO boardEditSelect(int no);
	public int boardUpdate(BoardDTO dto);
	public void boardHitCount(int no);
	public int boardDelete(BoardDTO dto);
	public int boardMultiLineDelete(List<Integer> noList);
	
	public int adboardDelete(BoardDTO dto);
	public int adboardMultiLineDelete(List<Integer> noList);
}
