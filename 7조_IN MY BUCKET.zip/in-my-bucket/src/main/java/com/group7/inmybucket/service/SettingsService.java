package com.group7.inmybucket.service;

public interface SettingsService {
	public String getUserEmail(String userid);
	public Integer getProfileVisible(String userid);
	public int profileVisibleUpdate(String userid);
}
