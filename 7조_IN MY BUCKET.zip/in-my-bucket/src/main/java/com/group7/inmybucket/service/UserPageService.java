package com.group7.inmybucket.service;

import java.util.List;

import com.group7.inmybucket.dto.FeedDTO;
import com.group7.inmybucket.dto.ProfileDTO;
import com.group7.inmybucket.vo.UserDataVO;
import com.group7.inmybucket.vo.UserFeedVO;

public interface UserPageService {
	public ProfileDTO getProfile(String userid);
	public String getUsernick(String userid);
	public UserDataVO getUserData(String userid);
	public int getProfileVisible(String userid);
	public int feedCount(UserFeedVO vo);
	public List<FeedDTO> listUser(UserFeedVO vo);
}
