package com.group7.inmybucket.dto;

public class ReplyDTO {
	private int comment_no;
	private int bucket_no; // 원글번호
	private String comment_content;
	private String userid;
	private String comment_writedate;
	
	
	
	@Override
	public String toString() {
		return "ReplyDTO [comment_no=" + comment_no + ", bucket_no=" + bucket_no + ", comment_content="
				+ comment_content + ", userid=" + userid + ", comment_writedate=" + comment_writedate + "]";
	}
	public int getComment_no() {
		return comment_no;
	}
	public void setComment_no(int comment_no) {
		this.comment_no = comment_no;
	}
	public int getBucket_no() {
		return bucket_no;
	}
	public void setBucket_no(int bucket_no) {
		this.bucket_no = bucket_no;
	}
	public String getComment_content() {
		return comment_content;
	}
	public void setComment_content(String comment_content) {
		this.comment_content = comment_content;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getComment_writedate() {
		return comment_writedate;
	}
	public void setComment_writedate(String comment_writedate) {
		this.comment_writedate = comment_writedate;
	}
	
	
	
}
