package com.group7.inmybucket;

public class RootDirectory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String rootPath = System.getProperty("user.dir");
		System.out.println(rootPath);
	}

}
