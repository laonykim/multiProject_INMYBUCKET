package com.group7.inmybucket.vo;

public class UserDataVO {
	private Integer bucketCountAll; // 등록한 버킷 수
	private Integer bucketCountGroup; // 참여한 그룹버킷 수
	private Integer bucketAccomplishedRate; // 버킷 달성률
	
	
	
	@Override
	public String toString() {
		return "UserDataVO [bucketCountAll=" + bucketCountAll + ", bucketCountGroup=" + bucketCountGroup
				+ ", bucketAccomplishedRate=" + bucketAccomplishedRate + "]";
	}
	public Integer getBucketCountAll() {
		return bucketCountAll;
	}
	public void setBucketCountAll(Integer bucketCountAll) {
		this.bucketCountAll = bucketCountAll;
	}
	public Integer getBucketCountGroup() {
		return bucketCountGroup;
	}
	public void setBucketCountGroup(Integer bucketCountGroup) {
		this.bucketCountGroup = bucketCountGroup;
	}
	public Integer getBucketAccomplishedRate() {
		return bucketAccomplishedRate;
	}
	public void setBucketAccomplishedRate(Integer bucketAccomplishedRate) {
		this.bucketAccomplishedRate = bucketAccomplishedRate;
	}
	
}
