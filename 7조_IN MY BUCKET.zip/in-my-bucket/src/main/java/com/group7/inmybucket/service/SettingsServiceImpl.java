package com.group7.inmybucket.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.SettingsDAO;

@Service
public class SettingsServiceImpl implements SettingsService {
	@Inject
	SettingsDAO dao;

	@Override
	public String getUserEmail(String userid) {
		return dao.getUserEmail(userid);
	}

	@Override
	public Integer getProfileVisible(String userid) {
		return dao.getProfileVisible(userid);
	}

	@Override
	public int profileVisibleUpdate(String userid) {
		return dao.profileVisibleUpdate(userid);
	}

}
