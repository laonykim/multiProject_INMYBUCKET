package com.group7.inmybucket.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.ReplyDAO;
import com.group7.inmybucket.dto.ReplyDTO;

@Service
public class ReplyServiceImpl implements ReplyService {

	@Inject
	ReplyDAO dao;
	
	@Override
	public int replyInsert(ReplyDTO dto) {
		return dao.replyInsert(dto);
	}

	@Override
	public List<ReplyDTO> replyListSelect(int bucket_no) {
		return dao.replyListSelect(bucket_no);
	}

	@Override
	public int replyUpdate(ReplyDTO dto) {
		return dao.replyUpdate(dto);
	}

	@Override
	public int replyDelete(int comment_no, String userid) {
		return dao.replyDelete(comment_no, userid);
	}

}
