package com.group7.inmybucket.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.BucketDAO;
import com.group7.inmybucket.dto.BucketDTO;
import com.group7.inmybucket.dto.ImageFileDTO;
import com.group7.inmybucket.vo.LikeVO;

@Service
public class BucketServiceImpl implements BucketService {

	@Inject
	BucketDAO dao;
	
	@Override
	public int bucketInsert(BucketDTO dto) {
		return dao.bucketInsert(dto);
	}

	@Override
	public int imageFileInsert(List<ImageFileDTO> filelist) {
		return dao.imageFileInsert(filelist);
	}

	@Override
	public List<BucketDTO> bucketAllSelect() {
		return dao.bucketAllSelect();
	}

	@Override
	public BucketDTO bucketSelect(int bucket_no) {
		return dao.bucketSelect(bucket_no);
	}

	@Override
	public List<ImageFileDTO> imageFileSelect(int bucket_no) {
		return dao.imageFileSelect(bucket_no);
	}

	@Override
	public BucketDTO bucketEditSelect(int bucket_no, String userid) {
		return dao.bucketEditSelect(bucket_no, userid);
	}

	@Override
	public List<String> imageFilenameList(int bucket_no) {
		return dao.imageFilenameList(bucket_no);
	}

	@Override
	public int bucketEditUpdate(BucketDTO dto) {
		return dao.bucketEditUpdate(dto);
	}

	@Override
	public int bucketEditDelete(int bucket_no, String userid) {
		return dao.bucketEditDelete(bucket_no, userid);
	}

	@Override
	public int imageFileDelete(int bucket_no) {
		return dao.imageFileDelete(bucket_no);
	}

	@Override
	public int imageFileEditInsert(List<ImageFileDTO> imageDTOList) {
		return dao.imageFileEditInsert(imageDTOList);
	}

	@Override
	public int bucketDelete(int bucket_no) {
		return dao.bucketDelete(bucket_no);
	}

	@Override
	public BucketDTO bucketReportSelect(int bucket_no, String userid) {
		return dao.bucketReportSelect(bucket_no, userid);
	}

	@Override
	public int bucketSaveLike(LikeVO vo) {
		return dao.bucketSaveLike(vo);
	}

	@Override
	public int bucketLikeUp(LikeVO vo) {
		return dao.bucketLikeUp(vo);
	}

	@Override
	public int bucketRemoveLike(LikeVO vo) {
		return dao.bucketRemoveLike(vo);
	}

	@Override
	public int bucketLikeDown(LikeVO vo) {
		return dao.bucketLikeDown(vo);
	}

	@Override
	public int bucketLikeCount(LikeVO vo) {
		return dao.bucketLikeCount(vo);
	}

	@Override
	public Integer isLike(LikeVO vo) {
		return dao.isLike(vo);
	}

	@Override
	public int commentCount(int bucket_no) {
		return dao.commentCount(bucket_no);
	}

	@Override
	public List<String> groupMemberNick(int bucket_no) {
		return dao.groupMemberNick(bucket_no);
	}

	@Override
	public int isGroupRequest(int bucket_no, String userid) {
		return dao.isGroupRequest(bucket_no, userid);
	}

	@Override
	public int groupQueueInsert(int bucket_no, String userid) {
		return dao.groupQueueInsert(bucket_no, userid);
	}

	@Override
	public int groupMemberInsert(BucketDTO dto) {
		return dao.groupMemberInsert(dto);
	}

}
