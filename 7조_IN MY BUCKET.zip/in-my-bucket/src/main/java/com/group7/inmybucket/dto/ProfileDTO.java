package com.group7.inmybucket.dto;

import org.springframework.web.multipart.MultipartFile;

public class ProfileDTO {
	private String userid;
	private String status_message;
	private String filename;
	private boolean profile_visible;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getStatus_message() {
		return status_message;
	}

	public void setStatus_message(String status_message) {
		this.status_message = status_message;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public boolean isProfile_visible() {
		return profile_visible;
	}

	public void setProfile_visible(boolean profile_visible) {
		this.profile_visible = profile_visible;
	}

	@Override
	public String toString() {
		return "ProfileDTO [userid=" + userid + ", status_message=" + status_message + ", filename=" + filename
				+ ", profile_visible=" + profile_visible + "]";
	}

	
}
