package com.group7.inmybucket.dto;

public class ReportDTO {
	// 원글 정보
	private int bucket_no; // 원글번호
	private String title; // 원글제목
	private String content; // 원글내용
	
	private int report_no; // 신고글 번호
	private String report_title; // 신고글 제목
	private String report_content; // 신고글 내용
	private int report_category; // 신고글 카테고리
	private String report_userid; // 신고자 id
	private String report_writedate; // 신고글 등록일
	private int report_progress; // 신고 후 처리결과
	
	
	@Override
	public String toString() {
		return "ReportDTO [bucket_no=" + bucket_no + ", title=" + title + ", content=" + content + ", report_no="
				+ report_no + ", report_title=" + report_title + ", report_content=" + report_content
				+ ", report_category=" + report_category + ", report_userid=" + report_userid + ", report_writedate="
				+ report_writedate + ", report_progress=" + report_progress + "]";
	}
	public int getBucket_no() {
		return bucket_no;
	}
	public void setBucket_no(int bucket_no) {
		this.bucket_no = bucket_no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getReport_no() {
		return report_no;
	}
	public void setReport_no(int report_no) {
		this.report_no = report_no;
	}
	public String getReport_title() {
		return report_title;
	}
	public void setReport_title(String report_title) {
		this.report_title = report_title;
	}
	public String getReport_content() {
		return report_content;
	}
	public void setReport_content(String report_content) {
		this.report_content = report_content;
	}
	public int getReport_category() {
		return report_category;
	}
	public void setReport_category(int report_category) {
		this.report_category = report_category;
	}
	public String getReport_userid() {
		return report_userid;
	}
	public void setReport_userid(String report_userid) {
		this.report_userid = report_userid;
	}
	public String getReport_writedate() {
		return report_writedate;
	}
	public void setReport_writedate(String report_writedate) {
		this.report_writedate = report_writedate;
	}
	public int getReport_progress() {
		return report_progress;
	}
	public void setReport_progress(int report_progress) {
		this.report_progress = report_progress;
	}
	
	
}
