package com.group7.inmybucket.dto;


public class FeedDTO {
	private int bucket_no;
	private String userid;
	private String title;
	private String writedate;
	private int progress_status; // 0 1 2
	private int like_count;
	private String category;
	private boolean isgroup;
	private boolean isvisible;
	private String filename;
	
	// 프로필 정보
	private String usernick;
	private String user_image_path;
	
	// 댓글 수
	public int comment_count;
	
	
	
	@Override
	public String toString() {
		return "FeedDTO [bucket_no=" + bucket_no + ", userid=" + userid + ", title=" + title + ", writedate="
				+ writedate + ", progress_status=" + progress_status + ", like_count=" + like_count + ", category="
				+ category + ", isgroup=" + isgroup + ", isvisible=" + isvisible + ", filename=" + filename
				+ ", usernick=" + usernick + ", user_image_path=" + user_image_path + ", comment_count=" + comment_count
				+ "]";
	}
	public int getBucket_no() {
		return bucket_no;
	}
	public void setBucket_no(int bucket_no) {
		this.bucket_no = bucket_no;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWritedate() {
		return writedate;
	}
	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}
	public int getProgress_status() {
		return progress_status;
	}
	public void setProgress_status(int progress_status) {
		this.progress_status = progress_status;
	}
	public int getLike_count() {
		return like_count;
	}
	public void setLike_count(int like_count) {
		this.like_count = like_count;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public boolean isIsgroup() {
		return isgroup;
	}
	public void setIsgroup(boolean isgroup) {
		this.isgroup = isgroup;
	}
	public boolean isIsvisible() {
		return isvisible;
	}
	public void setIsvisible(boolean isvisible) {
		this.isvisible = isvisible;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getUsernick() {
		return usernick;
	}
	public void setUsernick(String usernick) {
		this.usernick = usernick;
	}
	public String getUser_image_path() {
		return user_image_path;
	}
	public void setUser_image_path(String user_image_path) {
		this.user_image_path = user_image_path;
	}
	public int getComment_count() {
		return comment_count;
	}
	public void setComment_count(int comment_count) {
		this.comment_count = comment_count;
	}
	
	
	
}
