package com.group7.inmybucket.service;

import java.util.List;

import com.group7.inmybucket.dto.ReportDTO;

public interface ReportService {
	public int bucketReportInsert(ReportDTO dto);
	public List<ReportDTO> bucketReportAllSelect();
	public ReportDTO bucketReportSelect(int report_no);
	public int bucketReportEditUpdate(ReportDTO dto);
	public int bucketReportDelete(int report_no);
}
