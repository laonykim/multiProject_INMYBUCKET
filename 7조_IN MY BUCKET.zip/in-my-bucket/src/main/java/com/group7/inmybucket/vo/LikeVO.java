package com.group7.inmybucket.vo;

public class LikeVO {
	private String userid;
	private int bucket_no;
	private int like_no;
	
	
	@Override
	public String toString() {
		return "likeVO [userid=" + userid + ", bucket_no=" + bucket_no + ", like_no=" + like_no + "]";
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getBucket_no() {
		return bucket_no;
	}
	public void setBucket_no(int bucket_no) {
		this.bucket_no = bucket_no;
	}
	public int getLike_no() {
		return like_no;
	}
	public void setLike_no(int like_no) {
		this.like_no = like_no;
	}
	
	
	

}
