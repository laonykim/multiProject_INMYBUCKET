package com.group7.inmybucket.service;

import java.util.List;

import javax.inject.Inject;
import org.springframework.stereotype.Service;

import com.group7.inmybucket.dao.ReportDAO;
import com.group7.inmybucket.dto.ReportDTO;

@Service
public class ReportServiceImpl implements ReportService {

	@Inject
	ReportDAO dao;
	
	@Override
	public int bucketReportInsert(ReportDTO dto) {
		return dao.bucketReportInsert(dto);
	}

	@Override
	public List<ReportDTO> bucketReportAllSelect() {
		return dao.bucketReportAllSelect();
	}

	@Override
	public ReportDTO bucketReportSelect(int report_no) {
		return dao.bucketReportSelect(report_no);
	}

	@Override
	public int bucketReportEditUpdate(ReportDTO dto) {
		return dao.bucketReportEditUpdate(dto);
	}

	@Override
	public int bucketReportDelete(int report_no) {
		return dao.bucketReportDelete(report_no);
	}

}
